# Responsive Fixed Animated NavBar

A Pen created on CodePen.io. Original URL: [https://codepen.io/albizan/pen/mMWdWZ](https://codepen.io/albizan/pen/mMWdWZ).

This is a Responsive Fixed Navbar animated on scroll, it is similar to bootstrap navbar but here I didnt use any framework.
I hope this is usefull